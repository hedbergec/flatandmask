#!/usr/bin/env Rscript

args <- commandArgs(trailingOnly = TRUE)
repo_root <- normalizePath(if (length(args) >= 1L) args[[1L]] else getwd(), mustWork = TRUE)
output_root <- normalizePath(if (length(args) >= 2L) args[[2L]] else file.path(tempdir(), "JsonCSVMaskr-fixtures"), mustWork = FALSE)
secret_key <- if (length(args) >= 3L) args[[3L]] else "testkey123"
scenario_filter <- if (length(args) >= 4L) args[[4L]] else "*"
compare_root <- if (length(args) >= 5L) normalizePath(args[[5L]], mustWork = TRUE) else NA_character_
require_expected <- !is.na(compare_root)
example_secret_key <- "examplekey123"
smoke_secret_key <- "smoke-test"
nypd_secret_key <- "nypd-identity-test"

library(JsonCSVMaskr)

path <- function(...) file.path(repo_root, ...)
norm_field <- function(x) sub("^root\\.", "", x)
is_blank <- function(x) is.na(x) | !nzchar(x)

scenario <- function(name, type, input, mask_fields, expected = character(), secret = secret_key) {
  list(
    name = name,
    type = type,
    input = path(input),
    mask_fields = mask_fields,
    expected = file.path(repo_root, expected),
    secret = secret
  )
}

scenarios <- list(
  scenario("sample-json-basic", "json", file.path("example data", "sample.json"),
           c("name", "email"),
           c(file.path("test_output", "regression", "sample-json-basic"))),
  scenario("case-sensitive-values-csv", "csv", file.path("test_data", "test_case_sensitive_values.csv"),
           c("root.Value")),
  scenario("sample-json-basic-example", "json", file.path("example data", "sample.json"),
           c("name", "email"),
           c(file.path("example output", "sample-json-basic")),
           example_secret_key),
  scenario("complex-json-sensitive", "json", file.path("example data", "complex3.json"),
           c("firstName", "lastName", "email", "phone", "contacts.name", "contacts.email", "contacts.phone",
             "company.headquarters.street", "company.headquarters.city", "addresses.street", "addresses.city",
             "paymentMethods.cardNumber", "paymentMethods.cardholderName", "paymentMethods.billingAddress",
             "paymentMethods.accountHolderName"),
           c(file.path("test_output", "regression", "complex-json-sensitive"))),
  scenario("complex-json-sensitive-example", "json", file.path("example data", "complex3.json"),
           c("firstName", "lastName", "email", "phone", "contacts.name", "contacts.email", "contacts.phone",
             "company.headquarters.street", "company.headquarters.city", "addresses.street", "addresses.city",
             "paymentMethods.cardNumber", "paymentMethods.cardholderName", "paymentMethods.billingAddress",
             "paymentMethods.accountHolderName"),
           c(file.path("example output", "complex-json-sensitive")),
           example_secret_key),
  scenario("complex1-json-sensitive", "json", file.path("example data", "complex1.json"),
           c("name", "email", "address.street", "address.city", "contacts.number", "contacts.value")),
  scenario("complex2-json-sensitive", "json", file.path("example data", "complex2.json"),
           c("name", "email", "address.street", "address.city", "contacts.number", "contacts.value")),
  scenario("synthetic-hr-role-dates-json", "json", file.path("example data", "synthetic_hr_dataset_with_role_dates.json"),
           c("root.employees.employee_id", "root.employees.personal.first_name", "root.employees.personal.last_name",
             "root.employees.personal.ssn_like_test_value", "root.employees.contact.work_email",
             "root.employees.contact.personal_email", "root.employees.contact.phone", "root.employees.contact.address.street")),
  scenario("large-hr-json", "json", file.path("example data", "large_hr_dataset_approx_10mb.json"),
           c("root.employees.employee_id", "root.employees.name", "root.employees.ssn_like",
             "root.employees.history.department", "root.employees.history.job_title")),
  scenario("city-of-london-street", "csv", file.path("example data", "2026-02-city-of-london-street.csv"),
           c("Reported by", "Falls within", "Location"),
           c(file.path("test_output", "regression", "city-of-london-street"))),
  scenario("city-of-london-street-example", "csv", file.path("example data", "2026-02-city-of-london-street.csv"),
           c("Reported by", "Falls within", "Location"),
           c(file.path("example output", "city-of-london-street")),
           example_secret_key),
  scenario("city-of-london-stop-and-search", "csv", file.path("example data", "2026-02-city-of-london-stop-and-search.csv"),
           c("Gender", "Age range", "Self-defined ethnicity", "Officer-defined ethnicity")),
  scenario("city-of-london-outcomes", "csv", file.path("example data", "2026-02-city-of-london-outcomes.csv"),
           c("Reported by", "Falls within", "Location"),
           c(file.path("test_output", "regression", "city-of-london-outcomes"))),
  scenario("city-of-london-outcomes-example", "csv", file.path("example data", "2026-02-city-of-london-outcomes.csv"),
           c("Reported by", "Falls within", "Location"),
           c(file.path("example output", "city-of-london-outcomes")),
           example_secret_key),
  scenario("nypd-officer-profile-csv", "csv", file.path("example data", "NYPD_Officer_Profile_-_Title_Shield_History.csv"),
           c("PROFILE_ID", "SHIELD_NO"),
           c(file.path("test_output", "nypd_csv_identity")),
           nypd_secret_key),
  scenario("nypd-officer-profile-json", "json", file.path("example data", "NYPD Officer Profile - Title Shield History.json"),
           c("root.PROFILE_ID", "root.SHIELD_NO"),
           c(file.path("test_output", "nypd_json_identity")),
           nypd_secret_key),
  scenario("test-data-json", "json", file.path("test_data", "test_data.json"),
           c("root.ssn"),
           c(file.path("test_output", "regression", "test-data-json"))),
  scenario("regular-json-smoke", "json", file.path("test_data", "test_data.json"),
           c("root.ssn"),
           c(file.path("test_output", "regular_json_smoke")),
           smoke_secret_key),
  scenario("test-ndjson", "json", file.path("test_data", "test_ndjson.json"),
           c("root.email"),
           c(file.path("test_output", "regression", "test-ndjson"))),
  scenario("test-ndjson-smoke", "json", file.path("test_data", "test_ndjson.json"),
           c("root.email"),
           c(file.path("test_output", "ndjson")),
           smoke_secret_key),
  scenario("test-concatenated-json", "json", file.path("test_data", "test_concatenated.json"),
           c("root.email"),
           c(file.path("test_output", "regression", "test-concatenated-json"))),
  scenario("test-concatenated-json-smoke", "json", file.path("test_data", "test_concatenated.json"),
           c("root.email"),
           c(file.path("test_output", "concatenated")),
           smoke_secret_key),
  scenario("test-envelope-json", "json", file.path("test_data", "test_envelope.json"),
           c("root.email"),
           c(file.path("test_output", "regression", "test-envelope-json"))),
  scenario("test-envelope-json-smoke", "json", file.path("test_data", "test_envelope.json"),
           c("root.email"),
           c(file.path("test_output", "envelope")),
           smoke_secret_key),
  scenario("test-geojson", "json", file.path("test_data", "test_geojson.json"),
           c("root.properties.email"),
           c(file.path("test_output", "regression", "test-geojson"))),
  scenario("test-geojson-smoke", "json", file.path("test_data", "test_geojson.json"),
           c("root.properties.email"),
           c(file.path("test_output", "geojson")),
           smoke_secret_key),
  scenario("test-header-array-json", "json", file.path("test_data", "test_header_array.json"),
           c("root.email"),
           c(file.path("test_output", "regression", "test-header-array-json"))),
  scenario("test-header-array-json-smoke", "json", file.path("test_data", "test_header_array.json"),
           c("root.email"),
           c(file.path("test_output", "header_array")),
           smoke_secret_key),
  scenario("test-socrata-json", "json", file.path("test_data", "test_socrata.json"),
           c("root.PROFILE_ID", "root.SHIELD_NO"),
           c(file.path("test_output", "regression", "test-socrata-json"))),
  scenario("socrata-smoke", "json", file.path("example data", "NYPD Officer Profile - Title Shield History.json"),
           c("root.SHIELD_NO"),
           c(file.path("test_output", "socrata_smoke")),
           smoke_secret_key),
  scenario("test-data-csv", "csv", file.path("test_data", "test_data.csv"),
           c("root.Email", "root.Phone", "root.SSN"),
           c(file.path("test_output", "regression", "test-data-csv"))),
  scenario("csv-smoke", "csv", file.path("test_data", "test_data.csv"),
           c("root.SSN"),
           c(file.path("test_output", "csv_smoke")),
           smoke_secret_key),
  scenario("test-data-fewer-rows-csv", "csv", file.path("test_data", "test_data_fewer_rows.csv"),
           c("root.Email", "root.Phone", "root.SSN"),
           c(file.path("test_output", "regression", "test-data-fewer-rows-csv"))),
  scenario("test-data-missing-values-csv", "csv", file.path("test_data", "test_data_missing_values.csv"),
           c("root.Email", "root.Phone", "root.SSN"),
           c(file.path("test_output", "regression", "test-data-missing-values-csv")))
)

if (!identical(scenario_filter, "*")) {
  keep <- vapply(scenarios, function(sc) grepl(scenario_filter, sc$name), logical(1))
  scenarios <- scenarios[keep]
}

if (require_expected) {
  scenarios <- lapply(scenarios, function(sc) {
    sc$expected <- file.path(compare_root, sc$name)
    sc$secret <- secret_key
    sc
  })
  scenarios <- scenarios[vapply(scenarios, function(sc) dir.exists(sc$expected), logical(1))]
  if (!length(scenarios)) {
    stop("no common PowerShell/R scenario outputs found under ", compare_root, call. = FALSE)
  }
}

read_csv_safe <- function(file) {
  utils::read.csv(file, stringsAsFactors = FALSE, check.names = FALSE, fileEncoding = "UTF-8-BOM", na.strings = character())
}

canon_key <- function(data) {
  if (!nrow(data)) return(character())
  for (col in c("Original", "Masked", "Field", "RowIndex")) {
    if (!col %in% names(data)) data[[col]] <- ""
    data[[col]][is.na(data[[col]])] <- ""
  }
  paste(data$Original, data$Masked, norm_field(data$Field), data$RowIndex, sep = "\r")
}

assert_multiset_contains <- function(actual, expected, label) {
  actual_counts <- table(actual)
  expected_counts <- table(expected)
  missing <- names(expected_counts)[expected_counts > actual_counts[names(expected_counts)] | is.na(actual_counts[names(expected_counts)])]
  if (length(missing)) {
    stop(label, " missing expected row(s): ", paste(head(missing, 5L), collapse = " | "), call. = FALSE)
  }
}

validate_key_file <- function(actual_dir, expected_dir, sc) {
  actual_key_path <- file.path(actual_dir, "masking_key.csv")
  if (!file.exists(actual_key_path)) stop("missing R masking_key.csv", call. = FALSE)
  actual_key <- read_csv_safe(actual_key_path)

  if (nrow(actual_key)) {
    expected_masks <- ifelse(is_blank(actual_key$Original), "", vapply(actual_key$Original, get_masked_value, character(1), key = sc$secret))
    if (!all(actual_key$Masked == expected_masks)) {
      stop("R masking key contains values that do not match HMAC output", call. = FALSE)
    }
    allowed <- norm_field(sc$mask_fields)
    if (!all(norm_field(actual_key$Field) %in% allowed)) {
      stop("R masking key contains fields outside selected mask fields", call. = FALSE)
    }
  }

  expected_key_path <- file.path(expected_dir, "masking_key.csv")
  if (file.exists(expected_key_path)) {
    expected_key <- read_csv_safe(expected_key_path)
    if (nrow(expected_key)) {
      expected_masks <- ifelse(is_blank(expected_key$Original), "", vapply(expected_key$Original, get_masked_value, character(1), key = sc$secret))
      stale <- expected_key$Masked != expected_masks
      if (any(stale)) {
        message(sprintf("[%s] skipping %d stale PowerShell masking-key row(s) in %s whose masked value does not match its scenario secret",
                        sc$name, sum(stale), expected_key_path))
        expected_key <- expected_key[!stale, , drop = FALSE]
      }
    }
    assert_multiset_contains(canon_key(actual_key), canon_key(expected_key), paste(sc$name, basename(expected_dir), "masking key"))
  }
  invisible(TRUE)
}

get_stale_expected_masks <- function(expected_dir, sc) {
  expected_key_path <- file.path(expected_dir, "masking_key.csv")
  if (!file.exists(expected_key_path)) return(character())
  expected_key <- read_csv_safe(expected_key_path)
  if (!nrow(expected_key)) return(character())
  expected_masks <- ifelse(is_blank(expected_key$Original), "", vapply(expected_key$Original, get_masked_value, character(1), key = sc$secret))
  unique(expected_key$Masked[expected_key$Masked != expected_masks])
}

strip_synthetic_ids <- function(data) {
  data <- data[, !grepl("_id$", names(data)), drop = FALSE]
  data[] <- lapply(data, function(col) {
    col[is.na(col)] <- ""
    value <- as.character(col)
    value[tolower(value) == "true"] <- "true"
    value[tolower(value) == "false"] <- "false"
    value
  })
  data
}

actual_csv_for_expected <- function(expected_file, actual_dir) {
  same_name <- file.path(actual_dir, basename(expected_file))
  if (file.exists(same_name)) return(same_name)
  data_csv <- file.path(actual_dir, "data.csv")
  if (file.exists(data_csv)) return(data_csv)
  NA_character_
}

validate_csv_outputs <- function(actual_dir, expected_dir, sc) {
  stale_masks <- get_stale_expected_masks(expected_dir, sc)
  expected_csvs <- list.files(expected_dir, pattern = "\\.csv$", full.names = TRUE)
  expected_csvs <- expected_csvs[basename(expected_csvs) != "masking_key.csv"]
  for (expected_file in expected_csvs) {
    actual_file <- actual_csv_for_expected(expected_file, actual_dir)
    if (is.na(actual_file)) stop("missing comparable CSV for ", basename(expected_file), call. = FALSE)
    expected <- strip_synthetic_ids(read_csv_safe(expected_file))
    actual <- strip_synthetic_ids(read_csv_safe(actual_file))
    common <- intersect(names(expected), names(actual))
    if (!length(common)) next
    if (nrow(actual) < nrow(expected)) {
      stop("R CSV ", basename(actual_file), " has fewer rows than PowerShell fixture ", basename(expected_file), call. = FALSE)
    }
    expected <- expected[, common, drop = FALSE]
    actual <- actual[seq_len(nrow(expected)), common, drop = FALSE]
    mismatches <- expected != actual
    if (length(stale_masks)) mismatches[as.matrix(expected) %in% stale_masks] <- FALSE
    if (any(mismatches)) {
      stop("CSV content differs for ", basename(expected_file), " on common non-ID columns", call. = FALSE)
    }
  }
  invisible(TRUE)
}

validate_basic_outputs <- function(actual_dir, sc) {
  key_path <- file.path(actual_dir, "masking_key.csv")
  if (!file.exists(key_path)) stop("missing masking_key.csv", call. = FALSE)
  if (sc$type == "csv" && !file.exists(file.path(actual_dir, "data.csv"))) {
    stop("missing data.csv for CSV scenario", call. = FALSE)
  }
  if (sc$type == "json") {
    produced <- list.files(actual_dir, pattern = "(_masked\\.json|_masked\\.ndjson|\\.csv)$", full.names = TRUE)
    if (!length(produced)) stop("missing JSON masked/CSV outputs", call. = FALSE)
  }
  invisible(TRUE)
}

run_one <- function(sc) {
  actual_dir <- file.path(output_root, sc$name)
  if (dir.exists(actual_dir)) unlink(actual_dir, recursive = TRUE, force = TRUE)
  dir.create(actual_dir, recursive = TRUE, showWarnings = FALSE)
  invoke_masking(sc$input, actual_dir, secret_key = sc$secret, mask_fields = sc$mask_fields)
  validate_basic_outputs(actual_dir, sc)
  existing_expected <- sc$expected[dir.exists(sc$expected)]
  if (require_expected && !length(existing_expected)) {
    stop("missing PowerShell comparison output for ", sc$name, " under ", compare_root, call. = FALSE)
  }
  for (expected_dir in existing_expected) {
    validate_key_file(actual_dir, expected_dir, sc)
    validate_csv_outputs(actual_dir, expected_dir, sc)
  }
  data.frame(
    Scenario = sc$name,
    Type = sc$type,
    ExpectedDirs = length(existing_expected),
    Status = "PASS",
    stringsAsFactors = FALSE
  )
}

dir.create(output_root, recursive = TRUE, showWarnings = FALSE)
results <- list()
failures <- list()

for (sc in scenarios) {
  cat(sprintf("[%s] running %s\n", format(Sys.time(), "%H:%M:%S"), sc$name))
  result <- tryCatch(run_one(sc), error = function(e) {
    data.frame(
      Scenario = sc$name,
      Type = sc$type,
      ExpectedDirs = sum(dir.exists(sc$expected)),
      Status = paste("FAIL:", conditionMessage(e)),
      stringsAsFactors = FALSE
    )
  })
  results[[length(results) + 1L]] <- result
  if (!identical(result$Status, "PASS")) failures[[length(failures) + 1L]] <- result
}

summary <- do.call(rbind, results)
print(summary, row.names = FALSE)
cat("R output root:", output_root, "\n")

if (length(failures)) {
  stop(length(failures), " fixture validation scenario(s) failed", call. = FALSE)
}

cat("All fixture validation scenarios passed.\n")
